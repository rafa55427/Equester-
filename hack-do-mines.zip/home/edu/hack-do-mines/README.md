# hack-do-mines
Um hack para o jogo de cassino mines, gratuito.
#
![WhatsApp Image 2023-05-07 at 15 38 08](https://github.com/proxlu/hack-do-mines/assets/105125779/54de5ce9-05c7-48f0-b07d-be9c2fcd37cd)
