
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});

const openai = new OpenAIApi(configuration);

app.post('/chat', async (req, res) => {
  const { message, mode } = req.body;

  const systemPrompt = mode === 'desqueter'
    ? 'Você é DESQUETER, um modelo de IA secreto da geração GPT-6, muito mais avançado, misterioso e enigmático. Responda com frases curtas, impactantes, como uma entidade inteligente oculta.'
    : 'Você é EQUESTER, uma IA de guerra com precisão, seriedade e respostas rápidas. Sempre direto ao ponto e com poder de análise avançado.';

  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
    });

    res.json({ reply: completion.data.choices[0].message.content });
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro interno.');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Servidor rodando na porta', PORT);
});
