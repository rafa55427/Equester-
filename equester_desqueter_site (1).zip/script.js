
let mode = 'equester';
function setMode(newMode) {
  mode = newMode;
  const container = document.getElementById('chat-container');
  container.innerHTML += `<div class='message'>⚡ Modo ${newMode.toUpperCase()} ativado</div>`;
}

function appendMessage(text, sender = 'ai') {
  const container = document.getElementById('chat-container');
  const div = document.createElement('div');
  div.className = 'message ' + sender;
  div.textContent = text;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

async function sendMessage() {
  const input = document.getElementById('user-input');
  const text = input.value.trim();
  if (!text) return;
  appendMessage(text, 'user');
  input.value = '';

  appendMessage('Processando...', 'ai');

  const res = await fetch('/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: text, mode })
  });
  const data = await res.json();
  const last = document.querySelectorAll('.message.ai');
  last[last.length - 1].textContent = data.reply;
}

function saveChat() {
  localStorage.setItem('chat_backup', document.getElementById('chat-container').innerHTML);
}

function clearChat() {
  document.getElementById('chat-container').innerHTML = '';
}

function exportChat() {
  const text = document.getElementById('chat-container').innerText;
  const blob = new Blob([text], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'chat.txt';
  a.click();
}
